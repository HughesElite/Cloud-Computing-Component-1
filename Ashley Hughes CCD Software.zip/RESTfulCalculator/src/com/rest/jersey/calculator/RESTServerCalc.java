package com.rest.jersey.calculator;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/calc") // Root path for the calculator API
@Produces(MediaType.APPLICATION_JSON) // Set the default output type to JSON
public class RESTServerCalc {

    @GET
    public Response Calculator(@QueryParam("a") double a, @QueryParam("b") double b, @QueryParam("op") String op)
            throws JSONException {
        JSONObject json = new JSONObject();
        double c;

        switch (op) {
        case "+":
        case "add":
            c = a + b;
            break;
        case "-":
        case "sub":
            c = a - b;
            break;
        case "*":
        case "mul":
            c = a * b;
            break;
        case "/":
            if (b == 0) {
                return Response.status(400).entity("{\"result\":\"Division by zero error\"}").build();
            }
            c = a / b;
            break;
        default:
            return Response.status(400).entity("{\"result\":\"Invalid operator\"}").build();
        }

        json.put("result", c);
        return Response.status(200).entity(json.toString()).build();
    }

    // New POST method for Calculator
    @POST
    @Path("/calculate")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response calculatePost(String request) throws JSONException {
        JSONObject input = new JSONObject(request);
        double a = input.getDouble("a");
        double b = input.getDouble("b");
        String op = input.getString("op");

        JSONObject json = new JSONObject();
        double c;

        switch (op) {
        case "+":
        case "add":
            c = a + b;
            break;
        case "-":
        case "sub":
            c = a - b;
            break;
        case "*":
        case "mul":
            c = a * b;
            break;
        case "/":
            if (b == 0) {
                return Response.status(400).entity("{\"result\":\"Division by zero error\"}").build();
            }
            c = a / b;
            break;
        default:
            return Response.status(400).entity("{\"result\":\"Invalid operator\"}").build();
        }

        json.put("result", c);
        return Response.status(200).entity(json.toString()).build();
    }

    @GET
    @Path("/convertTemperature")
    public Response convertTemperature(@QueryParam("value") double value, @QueryParam("unit") String unit)
            throws JSONException {
        JSONObject json = new JSONObject();
        double convertedValue;

        switch (unit.toLowerCase()) {
        case "celsius-to-fahrenheit":
            convertedValue = (value * 9 / 5) + 32;
            json.put("unit", "Fahrenheit");
            break;
        case "fahrenheit-to-celsius":
            convertedValue = (value - 32) * 5 / 9;
            json.put("unit", "Celsius");
            break;
        case "celsius-to-kelvin":
            convertedValue = value + 273.15;
            json.put("unit", "Kelvin");
            break;
        case "kelvin-to-celsius":
            convertedValue = value - 273.15;
            json.put("unit", "Celsius");
            break;
        default:
            return Response.status(400).entity(
                    "{\"error\":\"Invalid unit. Valid options: celsius-to-fahrenheit, fahrenheit-to-celsius, celsius-to-kelvin, kelvin-to-celsius\"}")
                    .build();
        }

        json.put("originalValue", value);
        json.put("convertedValue", convertedValue);
        return Response.status(200).entity(json.toString()).build();
    }

    @GET
    @Path("/convertWeight")
    public Response convertWeight(@QueryParam("value") double value, @QueryParam("unit") String unit)
            throws JSONException {
        JSONObject json = new JSONObject();
        double convertedValue;

        switch (unit.toLowerCase()) {
        case "pound-to-kg":
            convertedValue = value * 0.453592; // Conversion factor
            json.put("unit", "Kilogram (kg)");
            break;
        case "kg-to-pound":
            convertedValue = value / 0.453592; // Inverse of the above conversion factor
            json.put("unit", "Pound (lbs)");
            break;
        default:
            return Response.status(400).entity("{\"error\":\"Invalid unit. Valid options: pound-to-kg, kg-to-pound\"}")
                    .build();
        }

        json.put("originalValue", value);
        json.put("convertedValue", convertedValue);
        return Response.status(200).entity(json.toString()).build();
    }

    @GET
    @Path("/calculateBMI")
    public Response calculateBMI(@QueryParam("weight") double weight, @QueryParam("height") double height)
            throws JSONException {
        JSONObject json = new JSONObject();

        if (weight <= 0 || height <= 0) {
            return Response.status(400).entity("{\"error\":\"Invalid weight or height\"}").build();
        }

        double bmi = weight / (height * height);
        json.put("weight", weight);
        json.put("height", height);
        json.put("bmi", bmi);

        return Response.status(200).entity(json.toString()).build();
    }

    @GET
    @Path("/calculateHipToWaistRatio")
    public Response calculateHipToWaistRatio(@QueryParam("waist") double waist, @QueryParam("hip") double hip)
            throws JSONException {
        JSONObject json = new JSONObject();

        if (waist <= 0 || hip <= 0) {
            return Response.status(400).entity("{\"error\":\"Invalid waist or hip measurement\"}").build();
        }

        double ratio = waist / hip;
        json.put("waist", waist);
        json.put("hip", hip);
        json.put("hipToWaistRatio", ratio);

        return Response.status(200).entity(json.toString()).build();
    }
}
