package com.rest.jersey.calculator;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

@Path("/")
public class WebResource {

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getIndexPage() {
		try {
			// you need this locally to source index HTML page
			File htmlFile = new File(
					"C:\\Users\\Hughes Portable Rig\\eclipse-workspace\\RESTfulCalculator\\index.html");

			String content = new String(Files.readAllBytes(Paths.get(htmlFile.toURI())));
			return content;
		} catch (Exception e) {
			return "<h1>Service has been deployed</h1>";
		}
	}
}
